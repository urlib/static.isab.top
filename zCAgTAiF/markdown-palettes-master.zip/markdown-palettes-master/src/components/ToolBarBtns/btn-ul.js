import { faListUl } from '@fortawesome/free-solid-svg-icons'

export default {
    name: 'ul',
    icon: faListUl,
    title: '无序列表',
    action: {
        insert: '- '
    }
}
