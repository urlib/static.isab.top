import { faListOl } from '@fortawesome/free-solid-svg-icons'

export default {
    name: 'ol',
    icon: faListOl,
    title: '有序列表',
    action: {
        insert: '1. '
    }
}
