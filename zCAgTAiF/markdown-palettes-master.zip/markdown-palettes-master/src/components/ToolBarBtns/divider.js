export default {
    name: '|'
}
