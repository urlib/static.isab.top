import { faMinus } from '@fortawesome/free-solid-svg-icons'

export default {
    name: 'hr',
    icon: faMinus,
    title: '分割线',
    action: {
        insert: '\n\n------------\n'
    }
}
