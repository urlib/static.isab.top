#include <bits/stdc++.h>
#define int long long
using namespace std;
int n, a[105005], b[105005], ans, cnt;
signed main()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        scanf("%lld", &a[i]), b[i] = a[i];
    sort(b + 1, b + n + 1);
    cnt = unique(b + 1, b + n + 1) - b - 1;
    //  cout<<cnt<<endl;
    for (int i = 1; i <= n; ++i)
        a[i] = lower_bound(b + 1, b + cnt + 1, a[i]) - b;
    for (int i = 1; i <= n; ++i)
    {
        bool aa[105005];
        int cnt = 0;
        memset(aa, 0, sizeof(aa));
        for (int j = i; j <= n; ++j)
        {
            if (!aa[a[j]])
                cnt++, aa[a[j]] = 1;
            ans += cnt * cnt;
        }
    }
    cout << ans << endl;
}