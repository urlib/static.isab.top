import requests
import concurrent.futures

url = 'https://www.zhihu.com/explore'
# 'https://v2ex.com/'
# 'https://codeforces.ml/'
# 'https://zh.wikimirror.org/'
# 'https://codeforces.ml/'
# 'http://47.103.204.220/'
# 'https://ipcounter.ihcr.top/'
s = concurrent.futures.ThreadPoolExecutor(max_workers=100)
for _ in range(100000):
    s.submit(requests.get, url)
