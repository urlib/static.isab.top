import os


class Config():
    pip_source = 'https://mirrors.aliyun.com/pypi/simple/'


class BasicSettings():
    def set_pip_source(self):
        os.system(
            f'pip config set global.index-url {config.pip_source}')


config = Config()
basic_settings = BasicSettings()

basic_settings.set_pip_source()

# import requests
try:
    import requests
except ImportError:
    os.system('pip install requests')
    exit(0)


def chdir():
    os.chdir(os.sys.path[0])


def main():
    chdir()


if __name__ == "__main__":
    main()
